local function on_init()
  storage.portal_state = storage.portal_state or {}
  storage.portal_cooldown = storage.portal_cooldown or {}
  game.print({"ricky-mod.hello"})
end

script.on_init(on_init)

local function get_surface_state(surface_index)
  local state = storage.portal_state[surface_index]

  if not state then
    state = {next = "a", a = nil, b = nil}
    storage.portal_state[surface_index] = state
  end

  return state
end

local function destroy_if_valid(entity)
  if entity and entity.valid then
    entity.destroy()
  end
end

local function place_portal(surface, position, portal_name)
  return surface.create_entity({
    name = portal_name,
    position = position,
    force = "neutral"
  })
end

script.on_event(defines.events.on_script_trigger_effect, function(event)
  if event.effect_id ~= "ricky-portal-hit" then
    return
  end

  local surface = game.surfaces[event.surface_index]
  if not surface then
    return
  end

  local target = event.target_position
  if not target then
    return
  end

  local state = get_surface_state(surface.index)

  if state.next == "a" then
    destroy_if_valid(state.a)
    state.a = place_portal(surface, target, "ricky-portal-a")
    state.next = "b"
  else
    destroy_if_valid(state.b)
    state.b = place_portal(surface, target, "ricky-portal-b")
    state.next = "a"
  end
end)

local function teleport_player(player, destination_entity)
  if not (destination_entity and destination_entity.valid) then
    return
  end

  local destination = destination_entity.surface.find_non_colliding_position(
    "character",
    destination_entity.position,
    2,
    0.1,
    true
  )

  if destination then
    player.teleport(destination, destination_entity.surface)
    storage.portal_cooldown[player.index] = game.tick + 30
  end
end

script.on_event(defines.events.on_tick, function(event)
  for _, player in pairs(game.connected_players) do
    local character = player.character
    if character and character.valid then
      local cooldown_tick = storage.portal_cooldown[player.index] or 0
      if event.tick >= cooldown_tick then
        local state = storage.portal_state[player.surface.index]
        if state and state.a and state.b and state.a.valid and state.b.valid then
          local position = character.position
          local dx_a = position.x - state.a.position.x
          local dy_a = position.y - state.a.position.y
          local dx_b = position.x - state.b.position.x
          local dy_b = position.y - state.b.position.y
          local range_sq = 0.7 * 0.7

          if (dx_a * dx_a + dy_a * dy_a) <= range_sq then
            teleport_player(player, state.b)
          elseif (dx_b * dx_b + dy_b * dy_b) <= range_sq then
            teleport_player(player, state.a)
          end
        end
      end
    end
  end
end)

commands.add_command("ricky_hello", {"ricky-mod.command_description"}, function()
  game.print({"ricky-mod.hello"})
end)
